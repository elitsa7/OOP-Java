package vehicle;

public interface VehicleImpl {
    String drive (double distance);
    void refuel (double liters);

}
