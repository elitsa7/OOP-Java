package carShopExtended;

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();
}
