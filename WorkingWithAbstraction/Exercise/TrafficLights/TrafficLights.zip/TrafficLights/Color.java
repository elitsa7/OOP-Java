package OOPExercise.WorkingWithAbstraction.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;
}
