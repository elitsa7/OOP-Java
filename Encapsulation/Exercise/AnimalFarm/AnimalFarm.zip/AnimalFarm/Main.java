package AnimalFarm;

public class Main {
    public static void main(String[] args) {
        Chicken chicken = new Chicken("Chichi", 10);
        System.out.println(chicken);
        Chicken chicken1 = new Chicken("Choko", 6);
        System.out.println(chicken1);
        Chicken chicken2 = new Chicken("Chichi", 15);
        System.out.println(chicken2);
    }
}
